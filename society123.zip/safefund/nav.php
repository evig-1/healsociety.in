<nav class="navbar navbar-expand-lg navbar-light global__transparent menu menu__scroll">
    <div class="container p-sm-0">
        <a class="navbar-brand menu__logo p-0 m-0" href="index.php"><img class="menu__logo-img"
                src="assets/img/logo2.png" alt="logo"></a>
        <button class="navbar-toggler menu__toggle" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Toggle navigation">
            <i class="fa-solid fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav m-auto menu__list my-3 my-lg-0">
                <!-- <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle menu__list-link menu__list-link--active" href="#" id="navbarDrop"
                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        home
                    </a>
                    <ul class="dropdown-menu menu__list-dropdown--ul overflow-hidden" aria-labelledby="navbarDrop">
                        <li><a class="dropdown-item" href="index-2.html">home</a></li>
                        <li><a class="dropdown-item" href="home-1.html">home one</a></li>
                        <li><a class="dropdown-item" href="home-2.html">home two</a></li>
                        <li><a class="dropdown-item" href="home-3.html">home three</a></li>
                        <li><a class="dropdown-item" href="home-4.html">home Four</a></li>
                    </ul>
                </li> -->
                <li class="nav-item ">
                    <a class="nav-link menu__list-link" href="index.php">Home</a>
                </li>
                
                
                <li class="nav-item">
                    <a class="nav-link menu__list-link" href="about.php">about us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link menu__list-link" href="events.php">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link menu__list-link" href="gallery.php">Gallery</a>
                </li>
                <!-- <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle menu__list-link" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        pages
                    </a>
                    <ul class="dropdown-menu menu__list-dropdown--ul" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="single-cases.html">single cases</a></li>
                        <li><a class="dropdown-item" href="donate.html">donate</a></li>
                        <li><a class="dropdown-item" href="blog-details.html">blog details</a></li>
                        <li><a class="dropdown-item" href="faqs.html">faqs</a></li>
                        <li><a class="dropdown-item" href="gallery.html">gallery</a></li>
                        <li><a class="dropdown-item" href="team.html">team</a></li>
                        <li><a class="dropdown-item" href="testimonials.html">testimonials</a></li>
                        <li><a class="dropdown-item" href="volunteer.html">volunteer</a></li>
                        <li><a class="dropdown-item" href="error.html">error</a></li>
                    </ul>
                </li> -->
                <!-- <li class="nav-item">
                    <a class="nav-link menu__list-link" href="blog.php">blog</a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link menu__list-link" href="contact.php">contact</a>
                </li>
            </ul>
            <div class="d-sm-flex d-lg-block gap-4 mt-3 mt-lg-0">
                <a href="donate.php" class="btn menu__btn menu__btn-in mb-3 mb-lg-0">Donate Now</a>
                <!-- <a href="signup.html" class="btn menu__btn menu__btn-up mb-3 mb-lg-0">sign
                    up</a> -->
            </div>
        </div>
    </div>
</nav>