<link rel="shortcut icon" href="assets/img/faveicon.png" type="image/x-icon">

<!-- Fontawsome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">


<!-- Google Fonts -->
<link rel="stylesheet" href="assets/fonts/Inter-VariableFont_slnt%2cwght.ttf">

<!-- Style CSS -->
<link rel="stylesheet" href="assets/css/style.css">