<!DOCTYPE html>
<html lang="en">



<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>

    <?php include 'link.php' ?>
</head>
<style>
    /* Modal styles */
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.8);
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 600px;
        position: relative;
        border-radius: 10px;
    }

    .modal-blog {
        text-align: center;
    }

    .modal-blog h2 {
        font-size: 2em;
        margin-bottom: 20px;
        color: #333;
        text-transform: capitalize;
    }

    .modal-blog img {
        width: 100%;
        height: auto;
        margin-bottom: 20px;
        border-radius: 10px;
    }

    .modal-blog p {
        font-size: 1.2em;
        line-height: 1.6;
        color: #666;
        text-align: justify;
    }

    .close {
        position: absolute;
        top: 10px;
        right: 20px;
        color: #aaa;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .close:hover,
    .close:focus {
        color: #000;
        text-decoration: none;
        cursor: pointer;
    }
</style>

<body>

    <!-- GoUp START -->
    <button id="topBtn"><i class="fas fa-arrow-up"></i></button>
    <!-- GoUp END -->

    <!-- Navbar START -->

    <?php include 'nav.php' ?>
    <?php include 'db.php' ?>
    <!-- Navbar END -->

    <!--  Banner START -->

    <div class="banner">
        <div class="banner__overlay">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center text-lg-start">
                        <h1 class="global__title global__title-dark text-capitalize">Events</h1>
                        <ul class="banner__ul">
                            <li class="banner__ul-list p-0">
                                <a class="banner__ul-link" href="index.php">
                                    home
                                </a>
                            </li>
                            <li class="banner__ul-list">
                                Events
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- <div class="banner__element d-none d-lg-block">
                    <img src="assets/img/element-3.svg" alt="image">
                </div> -->
                <div class="banner__polygon d-none d-lg-block">
                    <img src="assets/img/polygon.svg" alt="image">
                </div>
            </div>
        </div>
    </div>

    <!--  Banner END -->

    <!--  Cases START  -->

    <!-- <div class="cases global__py pt-0">
        <div class="container p-sm-0">
            <div class="cases__grid">
                <div class="card cases__card" data-aos="fade-down" data-aos-duration="1000">
                    <div class="cases__card-img">
                        <a href="single-cases.html">
                            <img class="img-fluid w-100" src="assets/img/img-1.png" alt="image">
                        </a>
                        <h4 class="cases__card-tag">health</h4>
                    </div>
                    <div class="card-body px-4">
                        <div class="d-flex">
                            <img class="cases__card-i" src="assets/img/location.svg" alt="icon">
                            <span class="cases__card-location ps-1">
                                South Africa
                            </span>
                        </div>
                        <div class="">
                            <a href="single-cases.html" class="cases__card-title">Providing health food for the
                                children</a>
                        </div>
                        <div class="cases__card-range">
                            <p class="global__desc m-0">Founded: 40.50%</p>
                            <div class="progress cases__card-progress">
                                <div class="progress-bar cases__card-progress--bar" role="progressbar"
                                    style="width: 40%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            <div class="cases__card-range--bottom">
                                <div class="d-flex align-items-center cases__card-range--bottom---m gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/box.svg" alt="icon">
                                    <span class="cases__card-range--price">
                                        Rasied: $34,000
                                    </span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/dollar-s.svg" alt="icon">
                                    <span class="cases__card-range--price">goal: $40,500</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card cases__card" data-aos="fade-down" data-aos-duration="1000">
                    <div class="cases__card-img">
                        <a href="single-cases.html">
                            <img class="img-fluid w-100" src="assets/img/img-2.png" alt="image">
                        </a>
                        <h4 class="cases__card-tag">health</h4>
                    </div>
                    <div class="card-body px-4">
                        <div class="d-flex">
                            <img class="cases__card-i" src="assets/img/location.svg" alt="icon">
                            <span class="cases__card-location ps-1">
                                South Africa
                            </span>
                        </div>
                        <div class="">
                            <a href="single-cases.html" class="cases__card-title">Charity is a simple method to prove
                                kindness
                                of
                                nation</a>
                        </div>
                        <div class="cases__card-range">
                            <p class="global__desc m-0">Founded: 50.0%</p>
                            <div class="progress cases__card-progress">
                                <div class="progress-bar cases__card-progress--bar" role="progressbar"
                                    style="width: 50%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            <div class="cases__card-range--bottom">
                                <div class="d-flex align-items-center cases__card-range--bottom---m gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/box.svg" alt="icon">
                                    <span class="cases__card-range--price">
                                        Rasied: $34,000
                                    </span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/dollar-s.svg" alt="icon">
                                    <span class="cases__card-range--price">goal: $40,500</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card cases__card" data-aos="fade-down" data-aos-duration="1000">
                    <div class="cases__card-img">
                        <a href="single-cases.html">
                            <img class="img-fluid w-100" src="assets/img/img-3.png" alt="image">
                        </a>
                        <h4 class="cases__card-tag">health</h4>
                    </div>
                    <div class="card-body px-4">
                        <div class="d-flex">
                            <img class="cases__card-i" src="assets/img/location.svg" alt="icon">
                            <span class="cases__card-location ps-1">
                                South Africa
                            </span>
                        </div>
                        <div class="">
                            <a href="single-cases.html" class="cases__card-title">Charity is a simple method to prove
                                kindness
                                of
                                nation</a>
                        </div>
                        <div class="cases__card-range">
                            <p class="global__desc m-0">Founded: 60.50%</p>
                            <div class="progress cases__card-progress">
                                <div class="progress-bar cases__card-progress--bar" role="progressbar"
                                    style="width: 60%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            <div class="cases__card-range--bottom">
                                <div class="d-flex align-items-center cases__card-range--bottom---m gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/box.svg" alt="icon">
                                    <span class="cases__card-range--price">
                                        Rasied: $34,000
                                    </span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/dollar-s.svg" alt="icon">
                                    <span class="cases__card-range--price">goal: $40,500</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card cases__card" data-aos="fade-left" data-aos-duration="1000">
                    <div class="cases__card-img">
                        <a href="single-cases.html">
                            <img class="img-fluid w-100" src="assets/img/img-7.png" alt="image">
                        </a>
                        <h4 class="cases__card-tag">health</h4>
                    </div>
                    <div class="card-body px-4">
                        <div class="d-flex">
                            <img class="cases__card-i" src="assets/img/location.svg" alt="icon">
                            <span class="cases__card-location ps-1">
                                South Africa
                            </span>
                        </div>
                        <div class="">
                            <a href="single-cases.html" class="cases__card-title">Charity is a simple method to prove
                                kindness
                                of
                                nation</a>
                        </div>
                        <div class="cases__card-range">
                            <p class="global__desc m-0">Founded: 70.0%</p>
                            <div class="progress cases__card-progress">
                                <div class="progress-bar cases__card-progress--bar" role="progressbar"
                                    style="width: 70%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            <div class="cases__card-range--bottom">
                                <div class="d-flex align-items-center cases__card-range--bottom---m gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/box.svg" alt="icon">
                                    <span class="cases__card-range--price">
                                        Rasied: $34,000
                                    </span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/dollar-s.svg" alt="icon">
                                    <span class="cases__card-range--price">goal: $40,500</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card cases__card" data-aos="fade-left" data-aos-duration="1000">
                    <div class="cases__card-img">
                        <a href="single-cases.html">
                            <img class="img-fluid w-100" src="assets/img/img-8.png" alt="image">
                        </a>
                        <h4 class="cases__card-tag">health</h4>
                    </div>
                    <div class="card-body px-4">
                        <div class="d-flex">
                            <img class="cases__card-i" src="assets/img/location.svg" alt="icon">
                            <span class="cases__card-location ps-1">
                                South Africa
                            </span>
                        </div>
                        <div class="">
                            <a href="single-cases.html" class="cases__card-title">Providing health food for the
                                children</a>
                        </div>
                        <div class="cases__card-range">
                            <p class="global__desc m-0">Founded: 45.50%</p>
                            <div class="progress cases__card-progress">
                                <div class="progress-bar cases__card-progress--bar" role="progressbar"
                                    style="width: 45%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            <div class="cases__card-range--bottom">
                                <div class="d-flex align-items-center cases__card-range--bottom---m gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/box.svg" alt="icon">
                                    <span class="cases__card-range--price">
                                        Rasied: $34,000
                                    </span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/dollar-s.svg" alt="icon">
                                    <span class="cases__card-range--price">goal: $40,500</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card cases__card" data-aos="fade-left" data-aos-duration="1000">
                    <div class="cases__card-img">
                        <a href="single-cases.html">
                            <img class="img-fluid w-100" src="assets/img/img-9.png" alt="image">
                        </a>
                        <h4 class="cases__card-tag">health</h4>
                    </div>
                    <div class="card-body px-4">
                        <div class="d-flex">
                            <img class="cases__card-i" src="assets/img/location.svg" alt="icon">
                            <span class="cases__card-location ps-1">
                                South Africa
                            </span>
                        </div>
                        <div class="">
                            <a href="single-cases.html" class="cases__card-title">Providing health food for the
                                children</a>
                        </div>
                        <div class="cases__card-range">
                            <p class="global__desc m-0">Founded: 80.50%</p>
                            <div class="progress cases__card-progress">
                                <div class="progress-bar cases__card-progress--bar" role="progressbar"
                                    style="width: 80%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            <div class="cases__card-range--bottom">
                                <div class="d-flex align-items-center cases__card-range--bottom---m gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/box.svg" alt="icon">
                                    <span class="cases__card-range--price">
                                        Rasied: $34,000
                                    </span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/dollar-s.svg" alt="icon">
                                    <span class="cases__card-range--price">goal: $40,500</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card cases__card" data-aos="fade-right" data-aos-duration="1000">
                    <div class="cases__card-img">
                        <a href="single-cases.html">
                            <img class="img-fluid w-100" src="assets/img/img-10.png" alt="image">
                        </a>
                        <h4 class="cases__card-tag">health</h4>
                    </div>
                    <div class="card-body px-4">
                        <div class="d-flex">
                            <img class="cases__card-i" src="assets/img/location.svg" alt="icon">
                            <span class="cases__card-location ps-1">
                                South Africa
                            </span>
                        </div>
                        <div class="">
                            <a href="single-cases.html" class="cases__card-title">Providing health food for the
                                children</a>
                        </div>
                        <div class="cases__card-range">
                            <p class="global__desc m-0">Founded: 90.50%</p>
                            <div class="progress cases__card-progress">
                                <div class="progress-bar cases__card-progress--bar" role="progressbar"
                                    style="width: 90%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            <div class="cases__card-range--bottom">
                                <div class="d-flex align-items-center cases__card-range--bottom---m gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/box.svg" alt="icon">
                                    <span class="cases__card-range--price">
                                        Rasied: $34,000
                                    </span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/dollar-s.svg" alt="icon">
                                    <span class="cases__card-range--price">goal: $40,500</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card cases__card" data-aos="fade-right" data-aos-duration="1000">
                    <div class="cases__card-img">
                        <a href="single-cases.html">
                            <img class="img-fluid w-100" src="assets/img/img-2.png" alt="image">
                        </a>
                        <h4 class="cases__card-tag">health</h4>
                    </div>
                    <div class="card-body px-4">
                        <div class="d-flex">
                            <img class="cases__card-i" src="assets/img/location.svg" alt="icon">
                            <span class="cases__card-location ps-1">
                                South Africa
                            </span>
                        </div>
                        <div class="">
                            <a href="single-cases.html" class="cases__card-title">Providing health food for the
                                children</a>
                        </div>
                        <div class="cases__card-range">
                            <p class="global__desc m-0">Founded: 91.50%</p>
                            <div class="progress cases__card-progress">
                                <div class="progress-bar cases__card-progress--bar" role="progressbar"
                                    style="width: 91%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            <div class="cases__card-range--bottom">
                                <div class="d-flex align-items-center cases__card-range--bottom---m gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/box.svg" alt="icon">
                                    <span class="cases__card-range--price">
                                        Rasied: $34,000
                                    </span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/dollar-s.svg" alt="icon">
                                    <span class="cases__card-range--price">goal: $40,500</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card cases__card" data-aos="fade-right" data-aos-duration="1000">
                    <div class="cases__card-img">
                        <a href="single-cases.html">
                            <img class="img-fluid w-100" src="assets/img/img-12.png" alt="image">
                        </a>
                        <h4 class="cases__card-tag">health</h4>
                    </div>
                    <div class="card-body px-4">
                        <div class="d-flex">
                            <img class="cases__card-i" src="assets/img/location.svg" alt="icon">
                            <span class="cases__card-location ps-1">
                                South Africa
                            </span>
                        </div>
                        <div class="">
                            <a href="single-cases.html" class="cases__card-title">Providing health food for the
                                children</a>
                        </div>
                        <div class="cases__card-range">
                            <p class="global__desc m-0">Founded: 40.50%</p>
                            <div class="progress cases__card-progress">
                                <div class="progress-bar cases__card-progress--bar" role="progressbar"
                                    style="width: 40%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            <div class="cases__card-range--bottom">
                                <div class="d-flex align-items-center cases__card-range--bottom---m gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/box.svg" alt="icon">
                                    <span class="cases__card-range--price">
                                        Rasied: $34,000
                                    </span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <img class="cases__card-range--dollar" src="assets/img/dollar-s.svg" alt="icon">
                                    <span class="cases__card-range--price">goal: $40,500</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 text-center">
                <button class="cases__btn">see more</button>
            </div>
        </div>
    </div> -->




    <div class="cases global__py pt-0">
        <div class="container p-sm-0">
            <div class="row">
                <div class="col-12 col-md-9 col-lg-6 text-center m-auto" data-aos="fade-down" data-aos-duration="1000">
                    <h3 class="global__text">Our Events</h3>
                    <h2 class="global__heading">Explore Our Events and Make a Difference</h2>
                </div>
            </div>
            <div class="row cases__grid">
                <?php
                // Assuming $conn is your database connection
                $sql = "SELECT event_name, event_image, event_description FROM event";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <div class="card cases__card" data-aos="fade-down" data-aos-duration="1000">
                            <div class="cases__card-img">
                                <img class="img-fluid w-100" src="uploads/<?php echo $row['event_image']; ?>" alt="Event Image">
                            </div>
                            <div class="card-body px-4">
                                <div>
                                    <span class="cases__card-title"><?php echo $row['event_name']; ?></span>
                                </div>
                                <div class="cases__card-range">
                                    <a href="#" class="team__user"
                                        onclick="showEventDescription('<?php echo addslashes($row['event_name']); ?>', '<?php echo addslashes($row['event_description']); ?>', '<?php echo addslashes($row['event_image']); ?>')">
                                        <h6 class="m-0">Find Out More</h6>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo "No events found.";
                }
                ?>
            </div>
            <div class="row">
                <!-- <div class="col-12 text-center mt-4">
                    <a href="events.php" class="global__btn mt-4">View More</a>
                </div> -->
            </div>
        </div>
    </div>

    <div id="eventModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEventModal()">&times;</span>
            <div class="modal-blog">
                <h2 id="modalEventName"></h2>
                <img id="modalEventImage" class="img-fluid" src="" alt="Event Image">
                <p id="modalEventDescription"></p>
            </div>
        </div>
    </div>

    








    <!--  Cases END  -->

    <!--  Join_US START -->

    <div class="join">
        <div class="container p-sm-0">
            <div class="row">
                <div class="card join__card">
                    <img src="assets/img/BG-Element.png" class="img-fluid join__card-img" alt="image">
                    <div class="card-img-overlay join__card-layer">
                        <div class="col-11 col-md-7">
                            <!-- <h3 class="join__text global__text">Become a volenteer</h3> -->
                            <h2 class="join__heading global__heading" style="
    color: #fff;
">Every Bite Brings Brightness
                            </h2>
                            <!-- <button class="join__card-layer--btn global__btn"
                                onclick="window.location.href='gallery.php'">Discover More</button> -->
                                <a href="gallery.php" class="global__btn mt-4">Discover More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--  Join_US END -->

    <!--  Footer START -->

    <?php include 'footer.php' ?>

    <!--  Footer END -->

    <!-- Jquary -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <!-- Venobox -->
    <script src="assets/js/venobox.min.js"></script>
    <!-- Counter JS -->
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- Slick JS -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Aos JS -->
    <script src="assets/js/aos.js"></script>
    <!-- JS -->
    <script src="assets/js/app.js"></script>


    <!-- <script>

        function showEventDescription(name, description, image) {
            document.getElementById("modalEventName").textContent = name;
            document.getElementById("modalEventImage").src = "uploads/" + image;
            document.getElementById("modalEventDescription").textContent = description;
            document.getElementById("eventModal").style.display = "block";
        }

        function closeEventModal() {
            document.getElementById("eventModal").style.display = "none";
        }
    </script> -->
    
    <script>
        // Function to open the modal and populate its content
        function showEventDescription(name, description, image) {
            var modalEventName = document.getElementById("modalEventName");
            var modalEventDescription = document.getElementById("modalEventDescription");
            var modalEventImage = document.getElementById("modalEventImage");

            modalEventName.textContent = name;
            modalEventDescription.textContent = description;
            modalEventImage.src = "uploads/" + image;

            // Display the modal
            var modal = document.getElementById("eventModal");
            modal.style.display = "block";
        }

        // Function to close the modal
        function closeEventModal() {
            var modal = document.getElementById("eventModal");
            modal.style.display = "none";
        }
    </script>
</body>



</html>